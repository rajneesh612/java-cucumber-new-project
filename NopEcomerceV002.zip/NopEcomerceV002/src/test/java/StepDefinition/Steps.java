package StepDefinition;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import PageObject.LoginPage;
import io.cucumber.java.en.*;
import utilities.BrowserManager;

public class Steps {
	WebDriver driver;
	LoginPage loginPage;
	
	@Given("User launch {string} browser and go to {string}")
	public void user_launch_browser_and_go_to(String Browser, String url) {
	    BrowserManager.setDriver(Browser);
	    driver = BrowserManager.getDriver();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	    driver.get(url);
	    loginPage = new LoginPage(driver);
	    
	    
	}

	@When("user enters Email as {string} in the email field and password as {string} in the password field")
	public void user_enters_email_as_in_the_email_field_and_password_as_in_the_password_field(String email, String password) {
	    // Write code here that turns the phrase above into concrete actions
		//loginPage = new LoginPage();
	    loginPage.enter_email_address(email);
	    
	}

	@When("click on Login")
	public void click_on_login() {
	    // Write code here that turns the phrase above into concrete actions
	    loginPage.click_on_log_in_btn();
	}

	@Then("User should be successfully login")
	public void user_should_be_successfully_login() {
	    // Write code here that turns the phrase above into concrete actions
	    String expected_heading= "Dashboard / nopCommerce administration";
	    Assert.assertTrue(loginPage.dashboard_page_heading().equals(expected_heading));
	}

	@Then("Close the browser")
	public void close_the_browser() {
	    // Write code here that turns the phrase above into concrete actions
	    driver.close();
	}


}
