package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	
	WebDriver driver;
	
	
	  public LoginPage(WebDriver driver) 
	  { 
		  this.driver=driver;
	  
	  }
	 
		/*
		 * @FindBy(xpath="//input[@id='Email']")
		 * 
		 * @CacheLookup WebElement email_field;
		 * 
		 * @FindBy(id="Password")
		 * 
		 * @CacheLookup WebElement passwrd_field;
		 * 
		 * 
		 * @FindBy(xpath="(//button[normalize-space()='Log in'])[1]")
		 * 
		 * @CacheLookup WebElement login_btn;
		 */
	
	
	public void enter_email_address(String email) {
		
		WebElement email_field = driver.findElement(By.xpath("//input[@id='Email']"));
		email_field.clear();
		email_field.sendKeys(email);
	}
	
	public void enter_password(String password) {
		WebElement password_field = driver.findElement(By.id("Password"));
		password_field.clear();
		password_field.sendKeys(password);
	}
	
	public void click_on_log_in_btn() {
		
		WebElement login_btn = driver.findElement(By.xpath("(//button[normalize-space()='Log in'])[1]"));
		login_btn.click();
	}
	
	public String dashboard_page_heading() {
		return driver.getTitle();
	}

}
